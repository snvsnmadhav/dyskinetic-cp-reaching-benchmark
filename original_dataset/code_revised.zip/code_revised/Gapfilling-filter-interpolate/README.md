# AVI-DYS Demo

## Overview
This demo contains the code used to in an AVI-DYS study, to preprocess data from DeepLabCut. Code is passed on https://doi.org/10.48804/8LMRXT, KU Leuven RDR, V1 

Video Footage &rarr; Kinematic Extraction (DeepLabCut) &rarr; Post-Processing (Jupyter Notebook) &rarr; 

## Folder Contents

* environment.yml: Within the anaconda enviroment the exact packages and dependencies used in this study are defined
Alternatively install sktime run the following command in the anaconda promt: ```conda install -c conda-forge sktime```

#### Demo Files
* Data Folder:
    * 0-Raw Folder: Contains movement (X,Y coordinates) or skeleton (length,orientation) data for each participant, and for each side. These files have already been preconditioned with a p-cutoff of 0.8 and the left-side videos have been mirrored to resemble the right-side videos.

* post-processing-demo.ipynb: Begins with raw data (0-Raw folder) and ends with data that has been gap-filled, filtered, interplolated and summariezed data of eight repetitions
## How to Use
1. Make sure you've downloaded the entire demo folder 
2. If you are using Anaconda, install the environment (environment.yaml) provided in the demo folder.
3. Open the post-processing-demo.ipynb notebook, with the environment set to our provided environment.
4. Set the ```demo_path =```  or ```demo_folder``` variable in the second code block to the location of the demo folder on your machine
5. Run the notebook