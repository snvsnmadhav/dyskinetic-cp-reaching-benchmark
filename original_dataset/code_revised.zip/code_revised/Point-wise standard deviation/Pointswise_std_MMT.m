%% Wrist joint
folder = 'C:\Documents\REP\WRIST'; 
% Get a list of all files.
fileList = dir(fullfile(folder, '*.*'));
allFileNames = {fileList.name};
% Extract TD data
str_TD = 'TD';
for k = 1 : length(allFileNames)
	% Get this filename.
	thisFileName = fullfile(fileList(k).folder, allFileNames{k});
	% See if it contains our required pattern.
	if ~contains(thisFileName, str_TD, 'IgnoreCase', true)
		% Skip this file because the filename does not contain the required pattern.
		continue;
    end
    data_TD(k).wrist = readmatrix(thisFileName);
end
%% Extract DCP data
str_DCP = 'DCP';
for k = 1 : length(allFileNames)
	% Get this filename.
	thisFileName = fullfile(fileList(k).folder, allFileNames{k});
	% See if it contains our required pattern.
	if ~contains(thisFileName, str_DCP, 'IgnoreCase', true)
		% Skip this file because the filename does not contain the required pattern.
		continue;
    end
    data_DCP(k).wrist = readmatrix(thisFileName);
end

%% Elbow joint
folder = 'C:\Documents\REP\\REP\ELBOW'; 
% Get a list of all files.
fileList = dir(fullfile(folder, '*.*'));
allFileNames = {fileList.name};
% Extract TD data
str_TD = 'TD';
numFilesProcessed = 0;	% For fun, let's keep track of how many files we processed.
for k = 1 : length(allFileNames)
	% Get this filename.
	thisFileName = fullfile(fileList(k).folder, allFileNames{k});
	% See if it contains our required pattern.
	if ~contains(thisFileName, str_TD, 'IgnoreCase', true)
		% Skip this file because the filename does not contain the required pattern.
		continue;
    end
    data_TD(k).elbow = readmatrix(thisFileName);
end
% Extract DCP data
str_DCP = 'DCP';
numFilesProcessed = 0;	% For fun, let's keep track of how many files we processed.
for k = 1 : length(allFileNames)
	% Get this filename.
	thisFileName = fullfile(fileList(k).folder, allFileNames{k});
	% See if it contains our required pattern.
	if ~contains(thisFileName, str_DCP, 'IgnoreCase', true)
		% Skip this file because the filename does not contain the required pattern.
		continue;
    end
    data_DCP(k).elbow = readmatrix(thisFileName);
end

%% Calculate pointwise standard deviations
% DCP
idx = size(data_DCP,2);
for k = 1:idx
    if isempty(data_DCP(k).wrist)
    continue
    end
    std_DCP(k).WR1 = std(data_DCP(k).wrist(2:end,2:9),0,2);
    std_DCP_wr(k) = mean(std_DCP(k).WR1);

    if isempty(data_DCP(k).elbow)
    continue
    end
    std_DCP(k).EL1 = std(data_DCP(k).elbow(2:end,2:9),0,2);
    std_DCP_elb(k) = mean(std_DCP(k).EL1);
end

% TD
idx = size(data_TD,2);
for k = 1:idx
    if isempty(data_TD(k).wrist)
    continue
    end
    std_TD(k).WR1 = std(data_TD(k).wrist(2:end,2:9),0,2);
    std_TD_wr(k) = mean(std_TD(k).WR1);

    if isempty(data_TD(k).elbow)
    continue
    end
    std_TD(k).EL1 = std(data_TD(k).elbow(2:end,2:9),0,2);
    std_TD_elb(k) = mean(std_TD(k).EL1);
end

%% Write to excel
% Individual values
std_TD_elb_final = nonzeros(std_TD_elb);
std_DCP_elb_final = nonzeros(std_DCP_elb);
std_TD_wr_final = nonzeros(std_TD_wr);
std_DCP_wr_final = nonzeros(std_DCP_wr);

headers1 = {'TD','DCP'};
writecell(headers1,'pointwise_std.xls','Sheet',1,'Range','B1');
writematrix(std_TD_elb_final,'pointwise_std.xls','Sheet',1,'Range','B2:B35');
writematrix(std_DCP_elb_final,'pointwise_std.xls','Sheet',1,'Range','C2:C35');

writecell(headers1,'pointwise_std.xls','Sheet',2,'Range','B1');
writematrix(std_TD_wr_final,'pointwise_std.xls','Sheet',2,'Range','B2:B35');
writematrix(std_DCP_wr_final,'pointwise_std.xls','Sheet',2,'Range','C2:C35');

